# Acknowledgements

* Scott Kveton: Original creator of Ampache
* Robert Hopson
* Andy Morgan
* RosenSama
* latka
* Lamar Hansford
* Lacy Morrow
* Karl Vollmer (vollmerk)
* Paul Arthur MacIain (flowerysong)
* Chris Slamar (cslamar)
* Holger Brunn
* Kevin Purdy (purdyk)
* Charlie Smotherman (porthose)
* XGizzmo
* Spock
* Terence Theijn (pb1dft)
* Mark Kasson
* SoundOfEmotion
* Randy Perkins
* Ben Shields
* Afterster
* SUTJael
* Psy-Virus
* John Moore (jcwmoore)
* René Bigler (Razrael)
* Kaivo
* Ernest Wagner (wagnered)
* lotan
* brownl
* Deathcow
* kuzi-moto
* jleipsig
* AshotN
* cquike
* Rhythm-of-Time
* xoxefdp
* ruipin
* rsertelon
* alejandroliu
* ahoy
* Sodki
* KingOperator
* DEvmIb
* BLeeEZ
* ibmibmibm
* Tetram76
* stebe
* manuelglez86
* theTendo
* lusum: Our official Kodi addon developer
* RyanCopley: ampache.com domain name donation
