## x.x.x-develop

Notes about this release that can't be summed up in a log line

### Added

* The quick brown fox jumps over the lazy dog
* The quick brown fox jumps over the lazy dog
  * The quick brown fox jumps over the lazy dog
* NEW db options
  * The quick brown fox jumps over the lazy dog
  * The quick brown fox jumps over the lazy dog
* NEW config options
  * The quick brown fox jumps over the lazy dog
  * The quick brown fox jumps over the lazy dog
* NEW files
  * The quick brown fox jumps over the lazy dog
  * The quick brown fox jumps over the lazy dog
* NEW examples
  * The quick brown fox jumps over the lazy dog
  * The quick brown fox jumps over the lazy dog

### Changed

* The quick brown fox jumps over the lazy dog
* The quick brown fox jumps over the lazy dog

### Deprecated

* None

### Removed

* The quick brown fox jumps over the lazy dog
* The quick brown fox jumps over the lazy dog

### Fixed

* The quick brown fox jumps over the lazy dog
* The quick brown fox jumps over the lazy dog

### Security

* FIX CVE-2020-00000 The quick brown fox jumps over the lazy dog
* FIX CVE-2020-00001 The quick brown fox jumps over the lazy dog

### API x.x.x

Notes about this API release that can't be summed up in a log line

#### Added

* The quick brown fox jumps over the lazy dog
  * The quick brown fox jumps over the lazy dog
* The quick brown fox jumps over the lazy dog
* NEW API functions
  * api_method: The quick brown fox jumps over the lazy dog
  * api_method: The quick brown fox jumps over the lazy dog
  * api_method: The quick brown fox jumps over the lazy dog
  * api_method: The quick brown fox jumps over the lazy dog

#### Changed

* The quick brown fox jumps over the lazy dog
* The quick brown fox jumps over the lazy dog
* The quick brown fox jumps over the lazy dog
  * The quick brown fox jumps over the lazy dog
* The quick brown fox jumps over the lazy dog

#### Deprecated

* The quick brown fox jumps over the lazy dog
  * The quick brown fox jumps over the lazy dog
* The quick brown fox jumps over the lazy dog

#### Removed

* None

#### Fixed

* None

#### Security

* None