---
name: Feature request
about: Suggest a new feature for Ampache
title: "[Feature Request]"
labels: ''
assignees: ''

---

<!-- Before submitting a feature request, make sure to search to see if it's already been suggested.

Please be as descriptive as you can be about your feature. No request is too big or too small and if it make sense, there is a good chance it will be approved and make it into Ampache. However, there is no guarantee on the time-frame.

The quickest way for a feature to make it into Ampache, is for you to submit a pull request yourself! -->

## Describe what you don't like about Ampache, or what it is missing

## Describe how you would like the feature to work**
